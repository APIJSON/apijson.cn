# APIJSON前端上手 - Android 

### 1.下载后解压APIJSON-Demo工程<h3/>

[打开APIJSON-Demo的GitHub主页](https://github.com/APIJSON/APIJSON-Demo) &gt; Clone or download &gt; [Download ZIP](https://github.com/APIJSON/APIJSON-Demo/archive/master.zip) &gt; 解压到一个路径并记住这个路径。

<br />

### 2.用Android Studio运行Android工程<h3/>

如果IDE没安装，运行前先下载安装。<br />
我的配置是Windows 7 + JDK 1.7.0_71 + Android Studio 2.2 和 OSX EI Capitan + JDK 1.8.0_91 + Android Studio 3.0，其中系统和软件都是64位的。

1)打开<br />
Open an existing Android Studio project > 选择刚才解压路径下的APIJSON-Demo-Master/APIJSON-Android/APIJSONApp （或APIJSONTest） > OK

2)运行<br />
Run > Run app

<br />

### 3.测试接口<h3/>

选择发送APIJSON请求并等待显示结果。<br />
如果默认url不可用，修改为一个可用的，比如正在运行APIJSON后端工程的电脑的IPV4地址，然后点击查询按钮重新请求。

也可以直接使用 [APIAuto-机器学习 HTTP 接口工具](http://apijson.cn/api) 或 Postman 等其它 HTTP 接口工具，格式为 HTTP POST JSON，具体示例参考通用文档 <br />
https://github.com/Tencent/APIJSON/blob/master/Document.md
<br />
